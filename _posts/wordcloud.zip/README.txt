使用方法：
安装 Python 并运行 wc.py，获得 wordcloud.png
可自行修改 wc.py 以获得不同结果，但请不要 push