#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import os
import re
import jieba
import wordcloud
from random import randint


str = ''
for x in [x for x in os.listdir('.') if os.path.isfile(x) and os.path.splitext(x)[1]=='.md']:
    with open(x, 'r', encoding='utf-8') as f:
        str += f.read()

pattern = re.compile(u'\t|\n|\.|-|:|;|\)|/|\(|\?|"|[0-9]|\*|[a-zA-Z]')
str = re.sub(pattern, '', str)
word_list = jieba.cut(str, cut_all=False)
word_dict = ('吹奏部', '北宇治',
            '久石', '奏',
            '伞木', '希美', '伞哥哥',
            '黄前', '久美子',
            '小笠原', '晴香',
            '田中', '明日香',
            '剑崎', '梨梨花',
            '铠冢', '霙',
            )
for word in word_dict:
    jieba.add_word(word)
remove_words = ('的', '，', '和', '是', '随着', '对于', '对', '等', '能', '都', '。', ' ', '、', '中', '在', '了',
                '通常', '如果', '我们', '需要' ,'她' ,'也' ,'部', '“', '”', '与', '《', '》', '有', '而', '不', '但',
                '就', '这', '—', '>', '<', '没有', '上', '他', '就是', '一个', '自己')
str = " ".join(word_list)


def random_color_func(word=None, font_size=None, position=None,  orientation=None, font_path=None, random_state=None):
    h = 207
    s = 0
    l = randint(25, 50)
    return f'hsl({h}, {s}%, {l}%)'


wc = wordcloud.WordCloud(
    font_path='SourceHanSerifCN-Bold.otf',
    color_func=random_color_func,
    width=1280,
    height=1000,
    max_words=150,
    mode='RGBA',
    background_color=None,
    stopwords=remove_words
)
wc.generate(str)
wc.to_file('wordcloud.png')
